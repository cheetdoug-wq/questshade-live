using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Threading;

namespace QuestShade
{
    // FFmpeg on the same headset accepts this FLV feed and publishes it to RTMP(S).
    internal sealed class CameraRelay
    {
        internal static bool Requested;
        internal static volatile string Status = "Idle";
        private readonly BlockingCollection<byte[]> packets = new(48);
        private readonly TcpClient socket = new();
        private volatile bool closed;
        private bool videoReady, audioReady;

        internal CameraRelay(bool hasAudio)
        {
            Status = "Connecting to headset relay";
            new Thread(() => Send(hasAudio)) { IsBackground = true }.Start();
        }

        private void Send(bool audio)
        {
            try
            {
                socket.Connect(IPAddress.Loopback, 19350);
                socket.SendTimeout = 2500;
                using var stream = socket.GetStream();
                stream.Write(new byte[] {70,76,86,1,(byte)(audio ? 5 : 1),0,0,0,9,0,0,0,0});
                Status = "Camera feed connected";
                foreach (var packet in packets.GetConsumingEnumerable()) stream.Write(packet);
            }
            catch { if (!closed) Status = "Relay disconnected. Start the relay and retry."; }
            finally { closed = true; socket.Dispose(); }
        }

        internal void Stop()
        {
            if (!closed) Status = "Stopped";
            closed = true;
            packets.CompleteAdding();
        }

        internal void Format(bool video, IntPtr format)
        {
            if (closed) return;
            var config = ReadConfig(format, "csd-0");
            if (video)
            {
                var sets = new List<byte[]>(Nals(config));
                sets.AddRange(Nals(ReadConfig(format, "csd-1")));
                var sps = sets.Find(n => (n[0] & 31) == 7);
                var pps = sets.Find(n => (n[0] & 31) == 8);
                if (sps == null || sps.Length < 4 || pps == null) { Fail(); return; }
                using var data = new MemoryStream();
                data.Write(new byte[]{1,sps[1],sps[2],sps[3],255,225});
                Number(data,sps.Length,2); data.Write(sps);
                data.WriteByte(1); Number(data,pps.Length,2); data.Write(pps);
                Tag(true,true,true,0,data.ToArray());
                videoReady = true;
            }
            else if (config.Length > 0) { Tag(false,true,false,0,config); audioReady = true; }
            else Fail();
        }

        internal void Sample(bool video, IntPtr data, int size, long pts, bool key)
        {
            if (closed || !(video ? videoReady : audioReady)) return;
            var bytes = new byte[size];
            Marshal.Copy(data,bytes,0,size);
            if (video && Prefix(bytes,0) != 0)
            {
                using var converted = new MemoryStream();
                foreach (var nal in Nals(bytes)) { Number(converted,nal.Length,4); converted.Write(nal); }
                bytes = converted.ToArray();
            }
            Tag(video,false,key,(uint)(pts / 1000),bytes);
        }

        private void Fail()
        {
            Status = "Camera feed stopped. Restart the relay and recording.";
            closed = true;
            packets.CompleteAdding();
        }

        private void Tag(bool video, bool header, bool key, uint time, byte[] payload)
        {
            int length = payload.Length + (video ? 5 : 2);
            using var tag = new MemoryStream(length + 15);
            tag.WriteByte((byte)(video ? 9 : 8));
            Number(tag,length,3); Number(tag,time,3); tag.WriteByte((byte)(time >> 24)); Number(tag,0,3);
            tag.WriteByte((byte)(video ? (key ? 0x17 : 0x27) : 0xaf));
            tag.WriteByte((byte)(header ? 0 : 1));
            if (video) Number(tag,0,3);
            tag.Write(payload); Number(tag,length+11,4);
            if (!packets.TryAdd(tag.ToArray())) Fail();
        }

        private static void Number(Stream stream, long n, int count)
        {
            for (int i = count-1; i >= 0; i--) stream.WriteByte((byte)(n >> (8*i)));
        }

        private static int Prefix(byte[] b,int i)
        {
            if (i+2 >= b.Length || b[i]!=0 || b[i+1]!=0) return 0;
            if (b[i+2]==1) return 3;
            return i+3<b.Length && b[i+2]==0 && b[i+3]==1 ? 4 : 0;
        }

        private static IEnumerable<byte[]> Nals(byte[] b)
        {
            int start=0;
            while (start<b.Length)
            {
                int content=start+Prefix(b,start), end=content;
                while (end<b.Length && Prefix(b,end)==0) end++;
                if (end>content) yield return b[content..end];
                start=end;
            }
        }

        [DllImport("libmediandk.so")]
        [return: MarshalAs(UnmanagedType.U1)]
        private static extern bool AMediaFormat_getBuffer(IntPtr format,string name,out IntPtr data,out UIntPtr size);

        private static byte[] ReadConfig(IntPtr format,string name)
        {
            if (!AMediaFormat_getBuffer(format,name,out var data,out var size) || size.ToUInt64()>65535) return Array.Empty<byte>();
            var bytes=new byte[(int)size.ToUInt64()];
            Marshal.Copy(data,bytes,0,bytes.Length);
            return bytes;
        }
    }
}
