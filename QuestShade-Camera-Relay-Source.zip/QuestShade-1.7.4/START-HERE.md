# QuestShade camera relay prototype
Build on Chromebook in a .NET 8 Codespace. Put the loader references listed under ML in QuestShade.csproj into refs/ml, generated Quest game references listed under IA into refs/ia, and BoneLib.dll into refs. Run dotnet build QuestShade.csproj -c Release. The original Android shader bundle is included. Back up the installed mod before replacing it with bin/Quest/QuestShade.dll. Disable the optional QuestShade updater while using the fork.

On the Quest, this prototype requires a terminal environment with Bash and FFmpeg (for example Termux with the ffmpeg package). Run bash start-relay.sh there and enter the server and key locally for a TikTok account with LIVE encoder access. Keep the relay running in the background.

In BONELAB open BoneMenu → QuestShade → Camera → Shoot. Turn on “Send next recording to relay” and press “Record / stop”. Check “Relay status” and the TikTok LIVE dashboard for ingest confirmation. Stop the recording to end the feed. For another stream restart the relay script. Recording still saves to the gallery. Game audio and mic use the normal camera settings.

Chat currently requires opening your TikTok LIVE in the Quest Browser, muting playback and pinning it alongside BONELAB. There is no integrated chat overlay in this prototype. Headset multitasking, streaming performance, encoder access and ingest have not been verified.
