#!/usr/bin/env bash
set -eu
read -r -p 'TikTok LIVE server URL: ' server
read -rs -p 'Stream key: ' stream_key
echo
exec ffmpeg -hide_banner -loglevel quiet -f flv -i 'tcp://127.0.0.1:19350?listen=1' -map 0:v -map '0:a?' -c copy -f flv "${server%/}/${stream_key}"
